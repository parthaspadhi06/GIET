#include<stdio.h>
int main()
{
	float ms, h, m,s;
	printf("enter the value of milisecond");
	scanf("%f",&ms);
	h=ms/3600000;
	m=ms/60000;
	s=ms/1000;
	printf("hours=%f\n",h);
	printf("mintue=%F\n",m);
	printf("seconds=%f\n",s);
	return 0;
}
