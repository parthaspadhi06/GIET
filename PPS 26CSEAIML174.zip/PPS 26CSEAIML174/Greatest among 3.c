#include <stdio.h>
main(){
	int x=8,y=7,z=9;
	
	if(x>y){
		if(x>z){
			printf("X is greatest");
		}
		else{
			printf("Z is greatest");
		}
	}

	else{
		if(y>z){
			printf("Y is greatest");
		}
		else{
			printf("Z is greatest");
		}
	}
	return 0;
}
