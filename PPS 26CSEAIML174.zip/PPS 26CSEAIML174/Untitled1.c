#include <stdio.h>
main(){
	int x,y;
	printf("Enter 1st out of 2 Numbers: ");
	scanf("%d",&x);
	printf("\nEnter 2nd out of 2 Numbers: ");
	scanf("%d",&y);
	int res=(x>y)?x:y;
	printf("\nlargest number is: %d", res);
	return 0;
}
