#include <stdio.h>
main(){
	int x;
	printf("Enter a +ve number to find it's cube and non +ve to find square : ");
	scanf("%d",&x);
	if(x>0){
		printf("cube of your number %d is: %d", x, x*x*x);
	}
	else{
		printf("Square of %d is: %d", x, x*x);
	}
	return 0;
}
