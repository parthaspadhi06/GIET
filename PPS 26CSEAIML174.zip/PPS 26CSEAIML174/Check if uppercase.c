#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(isupper(x)){
		printf("X is in uppercase.");
	}

	else{
		printf("X is not in uppercase.");
	}
	return 0;
}
