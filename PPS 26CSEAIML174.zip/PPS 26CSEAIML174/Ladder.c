#include <stdio.h>
main(){
	int x;
	printf("Enter a +ve number to find it's cube and -ve to find square: ");
	scanf("%d",&x);
	if(x>0){
		printf("cube of your number %d is: %d", x, x*x*x);
	}
	else if(x=0){
		printf("Your Numer is nutral i.e, Zero");
	}
	else{
		printf("Square of %d is: %d", x, x*x);
	}
	return 0;
}
