#include <stdio.h>
#include <math.h>
main(){
	int i,n,so=0,se=0;
	printf("Enter a number for n: ");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
	   int c=sqrt(i);
	  if(c%i==0){
	     printf("%d, ", i);
     }
	}
	
	return 0;
}
