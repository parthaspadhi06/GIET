//greatest among 3 (switch)
#include<stdio.h>
#include<stdlib.h>
int main(){
	int a,b,c;
	printf("Enter 3 numbers: ");
	scanf("%d %d %d",&a,&b,&c);
	switch(a==b&&b==c){
		case 1:
		printf("A,B,C are same");
		exit(0);
		break;
	}
	switch(a>b&&a>c){
		case 1:
			printf("a is greatest");
			break;
		case 0:
			switch(b>c){
				case 1:
					printf("b is greatest");
					break;
				case 0:
					printf("c is greatest");
					break;
			}
			break;
	}
}
