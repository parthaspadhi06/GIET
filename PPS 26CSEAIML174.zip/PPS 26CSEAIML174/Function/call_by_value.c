#include<stdio.h>
void show(int x, int y){
	x=1000;
	y=2000;
	printf("the value of x = %d, y = %d\n", x, y);
}
int main(){
	int a=10,b=20;
	printf("Before function call value of a = %d and b = %d\n",a,b);
	show(a,b);
	printf("After function call value of a = %d and b = %d\n",a,b);

	return 0;
}
