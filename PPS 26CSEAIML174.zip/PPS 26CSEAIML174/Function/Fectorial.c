#include <stdio.h>
void factorial();
int main(){
	factorial();
	return 0;
}

//function with no argument and no return type.
void factorial(){
	int n,f=1,i;
	printf("Enter a number : ");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		f *= i;
	}
	printf("The factorial of the number is : %d",f);
}
