//WAP to print a greeting message on screen using recursion.
#include<stdio.h>
void displayMessage(int n){
	
	if(n>1){
		displayMessage(n-1);
	}
	printf("\nWelcome in recursion");
}

int main(){
	int x;
	printf("Enter number of times to greet: ");
	scanf("%d",&x);
	displayMessage(x);
	return 0;
}
