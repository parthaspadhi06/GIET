#include <stdio.h>
int factorial();
int main(){
	int r = factorial();
	printf("The factorial of the number is : %d",r);
	return 0;
}

//function with no argument but return type.
int factorial(){
	int n,f=1,i;
	printf("Enter a number : ");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		f *= i;
	}
	return f;
}
