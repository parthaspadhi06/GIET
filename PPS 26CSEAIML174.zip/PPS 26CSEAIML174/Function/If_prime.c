#include <stdio.h>
int prime();

int main() {
	int n;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("\n");
    int p = prime(n);
    if(p==0){
       printf("%d is prime",n);
    }
    else{
       printf("%d is not prime",n);
    }
    return 0;
}

//function with argument and return type.
int prime(int n){
	int i,x=0;
	for (i=2;i<=(n/2);i++){
        if(n%i==0){
           x++;
           break;
        }
    }
    return x;
}
