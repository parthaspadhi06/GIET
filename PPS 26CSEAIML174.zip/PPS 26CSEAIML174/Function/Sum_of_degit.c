#include <stdio.h>
int sum();
int main(){
	int n;
	printf("Enter a number : ");
	scanf("%d",&n);
	sum(n);
}

//function with argument but no return type.
int sum(int n){
	int s=0,i,z;
	float y;
	for(i=n;i>0;i= i/10){
		y=i%10;
		s += y;
	}
	printf("The sum of the degits of your number is : %d",s);
	return s;
}
