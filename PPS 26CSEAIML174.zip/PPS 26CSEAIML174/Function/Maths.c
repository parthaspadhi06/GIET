#include <stdio.h>
int sum();
int multi();
float div();
int sub();

int main() {
	int a,b;
    printf("Enter a number for A: ");
    scanf("%d", &a);
    printf("\n");
    printf("Enter a number for B: ");
    scanf("%d", &b);
    int add = sum(a,b);
    int sub1 = sub(a,b);
    float div1 = div(a,b);
    int multi1 = multi(a,b);
    
    printf("Sum = %d\n",add);
    printf("Sub = %d\n",sub1);
    printf("Multi = %d\n",multi1);
    printf("Div = %f\n",div1);
    return 0;
}

//function with argument and return type.
int sum(int a, int b){
	int s=a+b;
    return s;
}
int sub(int a, int b){
	int m=a-b;
    return m;
}
int multi(int a, int b){
	int p=a*b;
    return p;
}
float div(int a, int b){
	float d=a/b;
    return d;
}
