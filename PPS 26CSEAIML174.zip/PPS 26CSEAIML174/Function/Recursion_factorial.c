//WAP to print a greeting message on screen using recursion.
#include<stdio.h>
int getFactorial(int n){
	if(n==0){
		return 1;
	}
	return n*getFactorial(n-1);
}

int main(){
	int n;
	printf("Enter number to find it's factorial : ");
	scanf("%d",&n);
	int fact = getFactorial(n);
	printf("Factorial = %d",fact);
	return 0;
}
