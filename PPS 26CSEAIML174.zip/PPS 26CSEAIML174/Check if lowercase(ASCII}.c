#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(x>=65&&x<=122)
	{
		if(x>=97&&x<=122)
		{
			printf("X is in lowercase.");
		}

		else
		{
		printf("X is not in lowercase.");	
		}
	}
	else
	{
		printf("X is not an Alphabet.");
	}
	return 0;
} 
