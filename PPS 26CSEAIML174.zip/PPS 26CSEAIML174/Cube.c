#include <stdio.h>
main(){
	int x;
	printf("Enter a +ve number to find it's cube: ");
	scanf("%d",&x);
	if(x>0){
		printf("cube of your number %d is: %d", x, x*x*x);
	}
	else{
		printf("&d is not +ve", x);
	}
	return 0;
}
