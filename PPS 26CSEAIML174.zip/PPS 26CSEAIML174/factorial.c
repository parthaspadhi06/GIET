#include <stdio.h>

int main() {
    int i, n;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("factorials of %d are: ",n);
    printf("\n");
    for (i=1;i<=n;i++){
        if(n%i==0){
         printf("%d, ",i);  
        }
    }
    return 0;
}

