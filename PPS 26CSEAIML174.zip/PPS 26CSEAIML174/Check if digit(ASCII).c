#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(x>=48&&x<=57){
		printf("X is a digit.");
	}

	else{
		printf("X is not a digit.");
	}
	return 0;
}
