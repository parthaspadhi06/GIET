#include<stdio.h>
#include<math.h>
int main(){
	int a,b,c,d;
	float r,r1,r2;
	printf("\nenter 1 out 3 co-efficient: ");
	scanf("%d",&a);
	printf("\nenter 2 out 3 co-efficient: ");
	scanf("%d",&b);
	printf("\nenter 3 out 3 co-efficient: ");
	scanf("%d",&c);
//	coefficients ==> ax^2+bx+c=0
	d=(b*b)-4*a*c;
	if(d>0)
	{
		r1=((-b)+sqrt((b*b)-4.0*a*c))/(2.0*a);
		r2=((-b)-sqrt((b*b)-4.0*a*c))/(2.0*a);
		printf("\nfor your cofficients a,b&c; real roots are %f and %f",r1,r2);
		
	}
	else if(d==0){
		r=-b/(2.0*a);
		printf("\nfor your cofficients a,b&c; real root is %f",r);
	}
	else
	{
		printf("\nfor your cofficients a,b&c; the equation has no real roots ");
	}
}

