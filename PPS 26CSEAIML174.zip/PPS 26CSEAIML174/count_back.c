#include <stdio.h>
main(){
	int i,n;
	printf("Enter a number for n: ");
	scanf("%d",&n);
	for(i=n;i>=1;i--){
		printf("%d\n",i);
	}
	return 0;
}
