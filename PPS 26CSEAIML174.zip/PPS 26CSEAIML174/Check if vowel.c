#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(x=='A'||x=='E'||x=='I'||x=='O'||x=='U'||x=='a'||x=='e'||x=='i'||x=='o'||x=='u'){
		printf("X is a vowel.");
	}

	else{
		printf("X is not a vowel.");
	}
	return 0;
}
