#include <stdio.h>
main(){
	char x;
	printf("Enter an Alphabet X: ");
	scanf("%c",&x);
	if(x=='A'||x=='E'||x=='I'||x=='O'||x=='U'||x=='a'||x=='e'||x=='i'||x=='o'||x=='u'){
		printf("X is a vowel.");
	}

	else if((x>=65&&x>=90)||(x>=97&&x>=122)){
		printf("X is a consonent.");
	}
	else{
		printf("X is not an Alphabet");
	}
	return 0;
}
