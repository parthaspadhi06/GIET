#include <stdio.h>
main(){
	int i;
	
//	increment loop
	for(i=0;i<=10;i++){
		printf("Partha Sarathi Padhi\n");
	}
//	decrement loop
	for(i=10;i>=0;i--){
		printf("Partha Sarathi Padhi\n");
	}
	return 0;
}
