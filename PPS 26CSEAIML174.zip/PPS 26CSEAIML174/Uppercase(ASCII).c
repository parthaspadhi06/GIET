#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(x>=65&&x<=122)
	{
		if(x>=65&&x<=90)
		{
			printf("X is in uppercase.");
		}

		else
		{
		printf("X is not in uppercase.");	
		}
	}
	else
	{
		printf("X is not an Alphabet.");
	}
	return 0;
} 
