#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(isdigit(x)){
		printf("X is a digit.");
	}

	else{
		printf("X is not a digit.");
	}
	return 0;
}
