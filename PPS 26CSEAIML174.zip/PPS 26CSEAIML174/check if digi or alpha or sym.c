#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(x>=48&&x<=57){
		printf("X is a digit.");
	}

	else if((x>=65&&x>=90)||(x>=97&&x>=122)){
		printf("X is an Alphabet.");
	}
	else{
		printf("X is an Symbol.");
	}
	return 0;
}
