#include <stdio.h>
main(){
int r1,c1,r2,c2;
    int i,j,k;
    printf("Enter size of row and column for the 1st matrix: ");
    scanf("%d %d",&r1,&c1);
    int n[r1][c1];
    printf("Enter %d elements:\n", r1*c1);
    for (i=0;i<r1;i++)
    {
        for (j=0;j<c1;j++)
        {
            scanf("%d",&n[i][j]);
        }
    }
    printf("Enter size of row and column for the 2nd matrix: ");
    scanf("%d %d",&r2,&c2);
	printf("Sum of diagonal matrix is: ");
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		if(i==j){
			s=s+m[i][j];
		}
		}
	}
	printf("%d",s);
	return 0;
}
