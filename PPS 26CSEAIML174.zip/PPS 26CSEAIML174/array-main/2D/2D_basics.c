#include <stdio.h>
main(){
	int r,c;
	printf("Enter size of row and colomn : ");
	scanf("%d",&r);
	scanf("%d",&c);
	int i,j,marks[r][c];
	printf("Enter %d elements: ", r*c);
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		scanf("%d",&marks[i][j]);
		}
	}
	printf("Elements of the arrayes are: ");
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		printf("%d ",marks[i][j]);
		}
		printf("\n");
	}
	return 0;
}
