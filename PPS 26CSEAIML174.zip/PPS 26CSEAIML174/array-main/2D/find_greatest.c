#include <stdio.h>
main(){
	int r,c,g;
	printf("Enter size of row and colomn : ");
	scanf("%d",&r);
	scanf("%d",&c);
	int i,j,n[r][c];
	printf("Enter %d elements: ", r*c);
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		scanf("%d",&n[i][j]);
		}
	}
	printf("Greatest element of the array is: ");
	g=n[0][0];
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		 if(g<n[i][j]){
		 	g=n[i][j];
		 }
		}
	}
	printf("%d",g);
	return 0;
}
