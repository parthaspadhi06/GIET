#include <stdio.h>

int main()
{
    int r1,c1,r2,c2;
    int i,j,k;
    printf("Enter size of row and column for the 1st matrix: ");
    scanf("%d %d",&r1,&c1);
    int n[r1][c1];
    printf("Enter %d elements:\n", r1*c1);
    for (i=0;i<r1;i++)
    {
        for (j=0;j<c1;j++)
        {
            scanf("%d",&n[i][j]);
        }
    }
    printf("Enter size of row and column for the 2nd matrix: ");
    scanf("%d %d",&r2,&c2);
    if (c1!=r2)
    {
        printf("Matrix multiplication is not possible.\n");
        return 0;
    }
    int m[r2][c2];
    int p[r1][c2];
    printf("Enter %d elements:\n",r2*c2);
    for (i=0;i<r2;i++)
    {
        for (j=0;j<c2;j++)
        {
            scanf("%d",&m[i][j]);
        }
    }

    for (i=0;i<r1;i++)
    {
        for (j=0;j<c2;j++)
        {
            p[i][j]=0;
        }
    }

    for (i=0;i<r1;i++)
    {
        for (j=0;j<c2;j++)
        {
            for (k=0;k<c1;k++)
            {
                p[i][j]+=n[i][k]*m[k][j];
            }
        }
    }

    printf("Product of the two matrices is:\n");

    for (i=0;i<r1;i++)
    {
        for (j=0;j<c2;j++)
        {
            printf("%d ",p[i][j]);
        }
        printf("\n");
    }
 return 0;
}

