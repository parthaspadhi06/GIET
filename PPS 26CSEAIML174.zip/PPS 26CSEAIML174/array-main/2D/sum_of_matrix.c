#include <stdio.h>
main(){
	int r,c,s=0;
	printf("Enter size of row and colomn for the 2 matrix : ");
	scanf("%d",&r);
	scanf("%d",&c);
	int i,j,n[r][c];
	printf("Enter %d elements: ", r*c);
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		scanf("%d",&n[i][j]);
		}
	}
	int m[r][c];
	printf("Enter %d elements: ", r*c);
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		scanf("%d",&m[i][j]);
		}
	}
	printf("Sum of the two arrayes are: ");
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		printf("%d ",m[i][j]+n[i][j]);
		}
		printf("\n");
	}
	return 0;
}
