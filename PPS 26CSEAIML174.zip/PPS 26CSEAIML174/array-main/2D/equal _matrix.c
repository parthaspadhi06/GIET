#include <stdio.h>
main(){
	int r1,c1,r2,c2,x=0;
    int i,j,k;
    printf("Enter size of row and column for the 1st matrix: ");
    scanf("%d %d",&r1,&c1);
    int m[r1][c1];
    printf("Enter %d elements:\n", r1*c1);
    for (i=0;i<r1;i++)
    {
        for (j=0;j<c1;j++)
        {
            scanf("%d",&m[i][j]);
        }
    }
    printf("Enter size of row and column for the 2nd matrix: ");
    scanf("%d %d",&r2,&c2);
    printf("Enter %d elements:\n", r2*c2);
    int n[r2][c2];
    for (i=0;i<r2;i++)
    {
        for (j=0;j<c2;j++)
        {
            scanf("%d",&n[i][j]);
        }
    }
    if(r1==r2 && c1==c2){
		for(i=0;i<r1;i++){
			for(j=0;j<c1;j++){
				if(m[i][j]!=n[i][j]){
					x++;
				}
			}
		}
		if(x==0){
		printf("\nmatrixes are Equal");
		}
		else{
			printf("\nmatrixes are not Equal");	
		}
	}
	else{
		printf("\nmatrixes are not Equal");
	}
	return 0;
}
