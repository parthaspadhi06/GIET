#include <stdio.h>
main(){
	int r,c,s=0;
	printf("Enter size of row and colomn : ");
	scanf("%d",&r);
	scanf("%d",&c);
	int i,j,marks[r][c];
	printf("Enter %d elements: ", r*c);
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		scanf("%d",&marks[i][j]);
		}
	}
	printf("\nSum of the elements of the array is: ");
	
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		s=s+marks[i][j];
	 }
	}
	printf("%d",s);
	return 0;
}
