#include <stdio.h>
main(){
	int r,c;
	printf("Enter size of row and colomn : ");
	scanf("%d",&r);
	scanf("%d",&c);
	int i,j,m[r][c];
	printf("Enter %d elements: ", r*c);
	printf("\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		scanf("%d",&m[i][j]);
		}
	}
	printf("Transpose of the matrix is: ");
	printf("\n");
	for(i=0;i<c;i++){
		for(j=0;j<r;j++){
		printf("%d ",m[j][i]);
		}
		printf("\n");
	}
	return 0;
}
