#include <stdio.h>
int main()
{
int n,i,j,k=0;
	printf("Enter the array size");
	scanf("%d",&n);
	int a[n];
	
	for (i=0;i<n;i++){
		printf("Enter the value %d:", i+1);
		scanf("%d",&a[i]);
	}
	for (j=0;j<n;j++){
		k=k+a[j];
	}
	printf("the  sum of all elements of array is: %d",k);
	return 0;
}
