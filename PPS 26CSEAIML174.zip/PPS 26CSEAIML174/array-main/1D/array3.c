#include <stdio.h>
int main()
{
int n,i,j;
	printf("Enter the array size");
	scanf("%d",&n);
	int a[n],b[n];
	
	for (i=0;i<n;i++){
		printf("Enter the value %d:", i+1);
		scanf("%d",&a[i]);
	}
	for (j=0;j<n;j++){
		b[j]=a[j];
	}
	
		printf("the elements of array b[] are:");
	for (i=0;i<n;i++){
		printf("   \nb[%d]=%d",i,b[i]);
		
	}
	
	return 0;
}
