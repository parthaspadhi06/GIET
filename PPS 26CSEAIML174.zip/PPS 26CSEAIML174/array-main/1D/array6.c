#include <stdio.h>
int main()
{
int n,i,j,k;
	printf("Enter the array size");
	scanf("%d",&n);
	int a[n];

	for (i=0;i<n;i++){
		printf("Enter the value %d:", i+1);
		scanf("%d",&a[i]);
	}
	k=a[0];
	for (j=0;j<n;j++){
		if(k<a[j]){k=a[j];
		}
	} 
	printf("the largest number is %d",k);
	return 0;
}
