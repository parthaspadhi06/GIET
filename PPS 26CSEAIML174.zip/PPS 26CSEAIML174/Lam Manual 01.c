#include <stdio.h>
main(){
	int William=8, Manvi=7, Shyam=9;
	
	if(William>Manvi){
		if(William>Shyam){
			printf("William is most experienced.");
		}
		else{
			printf("Shyam is most experienced.");
		}
	}

	else{
		if(Manvi>Shyam){
			printf("Manvi is most experienced.");
		}
		else{
			printf("Shyam is most experienced.");
		}
	}
	return 0;
}
