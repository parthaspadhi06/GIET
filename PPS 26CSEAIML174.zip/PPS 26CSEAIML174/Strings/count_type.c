#include <stdio.h>
#include <string.h>
int main(){
	char string[30];
	int x[30],a=0,d=0,s=0;
	printf("String : ");
	gets(string);
	printf("\n");
	int n = strlen(string),i;
	for(i=0;i<n;i++){
		x[i]=string[i];
		if(x[i]<=90 && x[i]>=65||x[i]<=122 && x[i]>=97){
			a++;
		}
		else if(x[i]<=57 && x[i]>=48){
			d++;
		}
		else{
			s++;
		}
	}
	printf("\nNumber of alphabets : %d",a);
	printf("\nNumber of numbers : %d",d);
	printf("\nNumber of symbols : %d",s);
		
	return 0;
}
