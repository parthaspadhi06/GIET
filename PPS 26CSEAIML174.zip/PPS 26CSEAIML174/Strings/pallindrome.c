#include <stdio.h>
#include <string.h>
int main(){
	char string[30],p[30];
	printf("String : ");
	gets(string);
	strcpy(p,string);
	strrev(p);
	int x = strcmp(string,p);
	if(x==0){
		printf("It is a Pallindrome");
	}
	else{
		printf("It is not a pallindrome");
	}
	return 0;
}
