#include <stdio.h>
int main(){
	char name[30];
	printf("Name :");
	scanf("%s",name);
	int j;
	printf("%s",name);

		
	return 0;
}
