#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main(){
	char string[30];
	int x[30];
	printf("String : ");
	gets(string);
	printf("\n");
	int n = strlen(string),i;
	for(i=0;i<n;i++){
		
		if(isupper(string[i])){
			string[i]=tolower(string[i]);
		}
		else if(islower(string[i])){
			string[i]=toupper(string[i]);
		}
		else{
			continue;
		}
	}
	printf("string = %s",string);
	return 0;
}
