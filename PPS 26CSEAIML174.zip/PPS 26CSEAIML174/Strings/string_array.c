#include <stdio.h>
#include <string.h>
int main(){
	char name[30];
	printf("Name : ");
	gets(name);
	puts(name);
	printf("\n");
//	int j;
//	for(j=0;j<20;j++){
//		printf("%c",name[j]);
//	}
		
	return 0;
}
