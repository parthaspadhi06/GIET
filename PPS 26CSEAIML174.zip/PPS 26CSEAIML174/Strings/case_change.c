#include <stdio.h>
#include <string.h>
int main(){
	char string[30];
	int x[30];
	printf("String : ");
	gets(string);
	printf("\n");
	int n = strlen(string),i;
	for(i=0;i<n;i++){
		x[i]=string[i];
		if(x[i]<=90 && x[i]>=65){
			printf("%c",x[i]+32);
		}
		else{
			printf("%c",x[i]-32);
		}
	}
		
	return 0;
}
