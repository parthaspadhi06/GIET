#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){
	char string[30];
	int x[30],a=0,d=0,s=0;
	printf("String : ");
	gets(string);
	printf("\n");
	int n = strlen(string),i;
	for(i=0;i<n;i++){
		
		if(isspace(string[i])){
			continue;
		}
		else if(isalpha(string[i])){
			a++;
		}
		else if(isdigit(string[i])){
			d++;
		}
		else{
			s++;
		}
	}
	printf("\nNumber of alphabets : %d",a);
	printf("\nNumber of digits : %d",d);
	printf("\nNumber of symbols : %d",s);
		
	return 0;
}
