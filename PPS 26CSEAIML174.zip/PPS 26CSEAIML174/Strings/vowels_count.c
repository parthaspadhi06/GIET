#include <stdio.h>
#include <string.h>
int main(){
	char string[30];
	printf("String : ");
	gets(string);
	int n = strlen(string),i,j=0;
	for(i=0;i<=n;i++){
		if(string[i]=='a'||string[i]=='e'||string[i]=='i'||string[i]=='o'||string[i]=='u'||string[i]=='A'||string[i]=='E'||string[i]=='I'||string[i]=='O'||string[i]=='U'){
			j++;
		}
	}
	printf("number of vowels in your string is = %d",j);
		
	return 0;
}
