#include <stdio.h>
int main(){
	char name[30];
	printf("Name : ");
	gets(name);
	int j;
	printf("%s",name);
//	for(j=0;j<20;j++){
//		printf("%c",name[j]);
//	}
		
	return 0;
}
