#include<stdio.h>
main(){
	int x;
	printf("enter between 0 to 6: ");
	scanf("%d",&x);
	if(x==0){
		printf("Sunday");
	}
	else if(x==1){
		printf("Monday");
	}
	else if(x==2){
		printf("Tuesday");
	}
	else if(x==3){
		printf("Wednesday");
	}
	else if(x==4){
		printf("Thursday");
	}
	else if(x==5){
		printf("Friday");
	}
	else if(x==6){
		printf("Saturday");
	}
	else{
		printf("Enter a number between 0 to 6");
	}
	return 0;
}
