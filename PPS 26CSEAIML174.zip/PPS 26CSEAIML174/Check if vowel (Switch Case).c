#include <stdio.h>
main(){
	char x;
	printf("Enter an Alphabet X: ");
	scanf("%c",&x);
	switch (x){
		case 'A':
			printf("X is a vowel.");
			break;
		case 'E':
			printf("X is a vowel.");
			break;
		case 'I':
			printf("X is a vowel.");
			break;
		case 'O':
			printf("X is a vowel.");
			break;
		case 'U':
			printf("X is a vowel.");
			break;
		case 'a':
			printf("X is a vowel.");
			break;
		case 'e':
			printf("X is a vowel.");
			break;
		case 'i':
			printf("X is a vowel.");
			break;
		case 'o':
			printf("X is a vowel.");
			break;
		case 'u':
			printf("X is a vowel.");
			break;
		default:
			printf("X is not a Vowel.");
	}
	int y= (x>=65&&x>=90)||(x>=97&&x>=122);
	switch(y){
		case 0:
			printf(" X is not even an Alphabet.");
	}
	return 0;
}
