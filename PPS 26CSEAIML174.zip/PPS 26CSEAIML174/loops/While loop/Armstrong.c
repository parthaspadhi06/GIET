#include <stdio.h>

int main() {
    int n, temp, r, sum = 0, digits = 0, i, p;

    printf("Enter a number: ");
    scanf("%d", &n);

    temp = n;

    // Count number of digits
    while (temp != 0) {
        digits++;
        temp = temp / 10;
    }

    temp = n;

    // Calculate sum of digits raised to the power of number of digits
    while (temp != 0) {
        r = temp % 10;
        p = 1;
        i = 1;

        while (i <= digits) {
            p = p * r;
            i++;
        }

        sum = sum + p;
        temp = temp / 10;
    }

    if (sum == n)
        printf("%d is an Armstrong number.\n", n);
    else
        printf("%d is not an Armstrong number.\n", n);

    return 0;
}

