#include<stdio.h>
int main()
{
	int i,j,k,n;
	printf("enter number ");
	scanf("%d",&n);
	for(i=n;i>0;i--){
		for(j=0;j<=i-1;j++)
		printf(" ");
	for(k=1;k<=n-i+1;k++){
		printf("*");
	}
	printf("\n");
}
return 0;
}
