#include <stdio.h>

int main() {
    int n,a;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("\n");
    while(n!=0){
    	int r=n%10;
    	a++;
    	n=n/10;
	}
	printf("\nNumber of degits is %d",a);
    return 0;
}
