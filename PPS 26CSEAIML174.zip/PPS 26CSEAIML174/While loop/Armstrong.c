#include <stdio.h>

int main() {
    int n,i=1,b=1,x=0;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("\n");
    while(n!=0){
    	int r=n%10;
    	
    	while(i<=r){
    		
			b=b*i;
			
		}
		x=x+b;
    	n=n/10;
	}
	printf("%d, ",x);
    return 0;
}
