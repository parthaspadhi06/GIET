#include <stdio.h>

int main() {
    int n,a=0;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("\n");
    while(n!=0){
    	int r=n%10;
    	a=a+r;
    	n=n/10;
	}
	printf("\nSum of all degits is %d",a);
    return 0;
}
