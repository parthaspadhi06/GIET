#include <stdio.h>
main(){
	int i,n,so=0,se=0;
	printf("Enter a number for n: ");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		if(i%2==0){
			se=se+i;
		}
		else{
			so=so+i;
		}
	}
	printf("");
	printf("Sum of even numbers: %d\n",se);
	printf("Sum of odd numbers: %d",so);
	return 0;
}
