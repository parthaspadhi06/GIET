#include <stdio.h>
main(){
	int X,Y;
	char ch;
	printf("Enter arihmatic operator: ");
	scanf("%c", &ch);
	printf("Enter two numbers: ");
	scanf("%d%d", &X,&Y);
	switch (ch){
		case '+':
			printf("Addition = %d",X+Y);
			break;
		case '-':
			printf("Substraction = %d",X-Y);
			break;
		case '*':
			printf("Product = %d",X*Y);
			break;
		case '/':
			printf("Devision = %d",X/Y);
			break;
		case '%':
			printf("Mod = %d",X%Y);
			break;
		default:
			printf("Enter a valid arithmatic operator.");
		
	}
	return 0;
}
