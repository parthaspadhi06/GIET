#include <stdio.h>

int main() {
    int i,n,p=0;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("\n");
    for (i=2;i<=(n/2);i++){
        if(n%i==0){
           p++;
           break;
        }
    }
    if(p==0){
       printf("%d is prime",n);
    }
    else{
       printf("%d is not prime",n);
    }
    return 0;
}
