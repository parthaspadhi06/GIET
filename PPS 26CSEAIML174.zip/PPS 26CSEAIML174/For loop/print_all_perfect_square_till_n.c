#include <stdio.h>

int main() {
    int i, n;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("Perfect squares up to %d: ", n);
    printf("\n");
    for (i=1;i*i<=n;i++){
        printf("%d, ", i*i);
    }
    return 0;
}

