#include <stdio.h>

int main() {
    int i, n;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("\n");
    for (i=1;i<=10;i++){
        printf("\n%dx%d=%d ",n,i,i*i);
    }
    return 0;
}

