#include <stdio.h>

int main() {
    int i,f=1,n;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("factorial of %d is = ",n);
    for (i=1;i<=n;i++){
         f=f*i;
    }
    printf("%d",f);
    return 0;
}

