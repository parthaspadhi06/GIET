#include <stdio.h>

int main() {
    int i,n,c,a=0,b=1;
    printf("Enter a number for n: ");
    scanf("%d", &n);
    printf("%d, %d, ",a,b);
    for (i=3;i<=n;i++){
       c=a+b;
       if (i==n){
       	printf("%d",c);
	   }
	   else{
	   	printf("%d, ",c);
	   }
       
       a=b;
       b=c;
    }
    return 0;
}

