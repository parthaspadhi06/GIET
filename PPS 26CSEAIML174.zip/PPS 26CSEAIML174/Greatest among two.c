#include <stdio.h>
main(){
	int x,y;
	printf("Enter a number X: ");
	scanf("%d",&x);
	printf("Enter another number Y: ");
	scanf("%d",&y);
	if(x>y){
		printf("X is greater than Y.");
	}

	else{
		printf("Y is greater than X.");
	}
	return 0;
}
