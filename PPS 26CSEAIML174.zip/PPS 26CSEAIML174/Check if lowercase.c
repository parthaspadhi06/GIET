#include <stdio.h>
main(){
	char x;
	printf("Enter a Character X: ");
	scanf("%c",&x);
	if(islower(x)){
		printf("X is in lowercase.");
	}

	else{
		printf("X is not in lowercase.");
	}
	return 0;
}
