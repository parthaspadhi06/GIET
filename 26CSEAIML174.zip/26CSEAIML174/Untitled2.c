#include <stdio.h>
int main ()
{
	int a=123,b= 168;
	float c=5.932;
	double d=5.934567;
	long double e = 7.123456;
	printf("Value of a = %d\nValue of b = %i \nValue of c = %f \nValue of d = %lf\nValue of e = %lf",a,b,c,d,e);
	return 0;
}
