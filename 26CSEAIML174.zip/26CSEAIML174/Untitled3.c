#include <stdio.h>
int main ()
{
	printf("Enter a number to check if it's Even: ");
	int x;
	scanf("%d", &x);
	if(x%2==0){
		printf("It's Even!!");
	}
	else{
		printf("it's not Even!!!");
	}
	return 0;
}
