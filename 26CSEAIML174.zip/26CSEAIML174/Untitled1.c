#include <stdio.h>
int main ()
{
	printf("Name: Partha Sarathi Padhi\nCollege Name: Gandhi Institute of Engineering and Technology\nRoll no: 26CSEAIML174");
	return 0;
}
