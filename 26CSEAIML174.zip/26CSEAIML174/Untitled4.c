#include <stdio.h>
#include <math.h>
int main() {
    float a,b,c,s,area;
    printf("Enter first of three sides of the triangle: ");
    scanf("%f",&a);
    printf("Enter second of three sides of the triangle: ");
    scanf("%f",&b);
    printf("Enter third of three sides of the triangle: ");
    scanf("%f",&c);
    s = (a+b+c)/2;
    area = sqrt(s*(s-a)*(s-b)*(s-c));
    printf("\nArea of the triangle = %f sq. units",area);
    return 0;
}

