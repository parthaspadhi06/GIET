#include <stdio.h>
int main ()
{
	int a=123,b= 168;;
	printf("Value of a = %d\nValue of b = %i",a,b);
	return 0;
}
